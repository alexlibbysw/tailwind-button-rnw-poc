import React from "react";
import cx from "classnames";
// import { Pressable, StyleSheet, Text } from "react-native";
// import * as Colors from "../../Tokens/dist/variables";
import "./button.dist.css";

export type IconPosition = "left" | "right";

export type Platform = "web" | "app" | "ourworld";

export type ThemeColor =
  | "red"
  | "green"
  | "blue"
  | "purple"
  | "teal"
  | "pink"
  | "orange";

export type ButtonProps = {
  children?: React.ReactNode;
  role: string;
  stretch?: boolean;
  disabled?: boolean;
  dataTestid: string;
  iconName?: any;
  className: string;
  themeColor: ThemeColor;
  iconPosition?: IconPosition;
  onClick?: () => void;
};

export const Button: React.FC<ButtonProps> = ({
  children,
  iconName,
  role,
  className,
  stretch,
  disabled,
  dataTestid,
  themeColor,
  iconPosition = "right",
  ...props
}) => {
  const createElement = () => {
    return React.createElement(iconName, {
      width: 12,
      height: 12,
      color: "#000",
    });
  };
  return iconPosition === "left" ? (
    <>
      <button
        type="button"
        className={cx(className, "left", themeColor, {
          "is-disabled": disabled,
          stretch,
        })}
        data-testid={dataTestid}
        role={role}
        disabled={disabled}
        {...props}
      >
        {iconName && createElement()}
        {children}
      </button>

      {/* <Pressable
        onPress={() => alert("you clicked the primary button")}
        style={buttonStyles.button}
        disabled={disabled}
        {...props}
      >
        <Text style={buttonStyles.text}>{children} - RNW</Text>
      </Pressable> */}
    </>
  ) : (
    <>
      <button
        type="button"
        className={cx(className, "right", themeColor, {
          "is-disabled": disabled,
          stretch,
        })}
        role={role}
        disabled={disabled}
      >
        {children}
        {iconName && createElement()}
      </button>

      {/* <Pressable
        disabled={disabled}
        onPress={() => {}}
        style={buttonStyles.button}
        {...props}
      >
        <Text style={buttonStyles.text}>{children} - RNW</Text>
      </Pressable> */}
    </>
  );
};

// const buttonStyles = StyleSheet.create({
//   button: {
//     backgroundColor: Colors.ColorRed400,
//     borderRadius: 2,
//     minHeight: "56px",
//     borderTopLeftRadius: 4,
//     borderBottomLeftRadius: 4,
//     borderTopRightRadius: 4,
//     borderBottomRightRadius: 4,
//     alignItems: "center",
//     justifyContent: "center",
//     width: "fit-content",
//     paddingTop: 8,
//     paddingBottom: 8,
//     paddingLeft: 24,
//     paddingRight: 24,
//   },
//   text: {
//     color: "#fff",
//     fontWeight: "500",
//     fontSize: 16,
//   },
// });

export default Button;
