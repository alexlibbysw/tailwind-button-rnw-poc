//Image Icon Inside the React Native Button
//https://aboutreact.com/image-icon-inside-the-react-native-button/

//import React in our code
import React from "react";
import * as Colors from "../../Tokens/dist/variables";

//import all the components we are going to use
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  Image,
  TouchableOpacity,
} from "react-native";

export type IconPosition = "left" | "right";

export type ThemeColor = "red" | "green";

export type ButtonProps = {
  children?: React.ReactNode;
  disabled?: boolean;
  iconPosition: IconPosition;
  themeColor: ThemeColor;
  iconName?: string;
  stretch?: boolean;
  dataTestid?: string;
};

export const ButtonRNW: React.FC<ButtonProps> = ({
  children,
  disabled,
  iconName,
  stretch,
  dataTestid,
  themeColor,
  iconPosition = "right",
  ...props
}) => {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={styles.container}>
        <TouchableOpacity
          style={[styles.button, styles[`${themeColor}Button`]]}
          activeOpacity={0.5}
          disabled={disabled}
          testID={dataTestid}
          onPress={() => alert("you clicked the primary button")}
          {...props}
        >
          {iconPosition === "left" ? (
            <>
              <Image
                source={{
                  uri: "https://raw.githubusercontent.com/AboutReact/sampleresource/master/facebook.png",
                }}
                style={styles.buttonImageIconStyle}
              />
              <Text style={styles.buttonTextStyle}>{children}</Text>
            </>
          ) : (
            <>
              <Text style={styles.buttonTextStyle}>{children}</Text>
              <Image
                source={{
                  uri: "https://raw.githubusercontent.com/AboutReact/sampleresource/master/facebook.png",
                }}
                style={styles.buttonImageIconStyle}
              />
            </>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  button: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 0.5,
    borderColor: "#fff",
    height: 40,
    borderRadius: 4,
    minHeight: "56px",
    borderTopLeftRadius: 4,
    borderBottomLeftRadius: 4,
    borderTopRightRadius: 4,
    borderBottomRightRadius: 4,
    justifyContent: "center",
    width: "fit-content",
    paddingTop: 8,
    paddingBottom: 8,
    paddingLeft: 24,
    paddingRight: 24,
    fontSize: "16px",
  },
  text: {
    color: "#fff",
    fontWeight: "500",
    fontSize: 16,
  },

  redButton: {
    backgroundColor: Colors.ColorRed400,
  },

  greenButton: {
    backgroundColor: Colors.ColorGreen400,
  },

  buttonImageIconStyle: {
    padding: 10,
    margin: 5,
    height: 25,
    width: 25,
    resizeMode: "stretch",
  },
  buttonTextStyle: {
    color: "#fff",
    marginBottom: 4,
    marginLeft: 10,
    fontSize: 16,
  },
});

export default ButtonRNW;
