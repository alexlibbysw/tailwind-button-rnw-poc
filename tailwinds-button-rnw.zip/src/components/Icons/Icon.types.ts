export interface IconProps extends React.SVGAttributes<SVGSVGElement> {
  width?: number;
  height?: number;
}
